# Add Hayek Enterprise Agents Here

Drop specialist `.md` agents into this folder, then click **Scan agents** in the app.

Example:
- DOTNET_ENTERPRISE_AGENT.md
- MOBILE_RELEASE_AGENT.md
- SECURITY_REVIEW_AGENT.md

Hayek Enterprise scans these files, infers setup needs, copies them into each project workspace, and adds them to the master company prompt.
